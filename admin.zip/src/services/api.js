import axios from 'axios';

const api = axios.create({
  baseURL: 'http://16.171.137.189/api', // Adjust as necessary
});

export default api;
