// src/components/BookList.js
import React, { useEffect, useState, useContext } from 'react';
import { Link } from 'react-router-dom';
import { fetchBooks } from '../services/api';


const BookList = () => {
  const [books, setBooks] = useState([]);

  const baseImageUrl = 'http://localhost:5000/'; 

  useEffect(() => {
    const getBooks = async () => {
      const booksData = await fetchBooks();
      console.log(booksData)
      setBooks(booksData);
    };

    getBooks();
  }, []);


  const handleAddToCart = (book) => {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const existingBook = cart.find(item => item.id === book.id);

    if (existingBook) {
      existingBook.quantity += 1;
    } else {
      cart.push({ ...book, quantity: 1 });
    }

    localStorage.setItem('cart', JSON.stringify(cart));
    alert('Product added to cart');
  };

  return (
    <div className="p-4 flex">
      <div className="flex-1">
        <h2 className="text-2xl font-bold mb-4">Books</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {books.map((book) => (
            <div key={book.id} className="bg-white p-4 rounded shadow">
              <img src={`${baseImageUrl}${book.cover_image}`} alt={book.title} className="mb-4 w-full h-48 object-cover" />
              <h3 className="text-xl font-semibold mb-2">{book.title}</h3>
              <p className="mb-2">{book.author}</p>
              <p className="mb-2">${book.price}</p>
              <p className="mb-2">{'⭐'.repeat(book.rating)}</p>
              <Link to={`/books/${book.id}`} className="text-blue-500 mb-2 inline-block">View Details</Link>
              <button
                onClick={() => handleAddToCart(book)}
                className="bg-blue-500 text-white px-4 py-2 rounded mt-2"
              >
                Add to Cart
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default BookList;
