import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Sidebar = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <div>
      <button
        className="lg:hidden p-4 text-white bg-gray-800"
        onClick={() => setIsOpen(!isOpen)}
      >
        ☰
      </button>
      <div
        className={`w-64 h-screen bg-gray-800 text-white p-4 fixed lg:static transition-transform ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        } lg:translate-x-0`}
      >
        <ul>
          <li><Link to="/" className="block py-2">Home</Link></li>
          <li><Link to="/categories/fiction" className="block py-2">Fiction</Link></li>
          <li><Link to="/categories/action" className="block py-2">Action</Link></li>
          <li><Link to="/categories/romance" className="block py-2">Romance</Link></li>
          <li><Link to="/categories/scifi" className="block py-2">Sci-Fi</Link></li>
          <li><Link to="/categories/mystery" className="block py-2">Mystery</Link></li>
          <li><Link to="/orders" className="block py-2">Orders</Link></li>
          {user && <li><button onClick={handleLogout} className="block py-2 w-full text-left">Logout</button></li>}
        </ul>
      </div>
    </div>
  );
};

export default Sidebar;
