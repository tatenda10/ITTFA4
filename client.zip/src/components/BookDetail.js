import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';

const BookDetail = () => {
  const { id } = useParams();
  const [book, setBook] = useState(null);
  const [items, setItems] = useState([]);

  useEffect(() => {
    const fetchBook = async () => {
      try {
        const response = await axios.get(`http://localhost:5000/api/books/${id}`);
        setBook(response.data);
        setItems(response.data.items); // assuming items are part of book data
      } catch (error) {
        console.error('Error fetching book details:', error);
      }
    };

    fetchBook();
  }, [id]);

  if (!book) {
    return <div>Loading...</div>;
  }

  return (
    <div className="p-4">
      <h2 className="text-2xl font-bold mb-4">{book.title}</h2>
      <p className="mb-4">{book.author}</p>
      <img 
        src={`http://localhost:5000/${book.cover_image.replace(/\\/g, '/')}`} 
        alt={book.title} 
        className="mb-4 w-full h-48 object-cover" 
      />
      <p className="mb-4">{book.description}</p>
      <p className="mb-4">${book.price}</p>
      <p className="mb-4">{'⭐'.repeat(book.rating)}</p>
      <h3 className="text-xl font-semibold mb-2">Related Items</h3>
      <ul>
        {items.map((item) => (
          <li key={item.id} className="mb-2">
            {item.name} - ${item.price}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default BookDetail;
