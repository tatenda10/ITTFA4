// src/App.js
import React from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import Login from './components/Login';
import Register from './components/Register';
import HomePage from './pages/HomePage';
import OrdersPage from './pages/OrdersPage';
import BookDetail from './components/BookDetail';
import Cart from './components/Cart';
import Sidebar from './components/Sidebar';
import { AuthProvider } from './context/AuthContext';
import { CartProvider } from './context/CartContext';
import FictionPage from './pages/FictionPage.js';
import ActionPage from './pages/ActionPage';
import RomancePage from './pages/RomancePage';
import SciFiPage from './pages/SciFiPage';
import MysteryPage from './pages/MysteryPage';
import BookList from './components/BookList.js';

const App = () => {
  return (
    <AuthProvider>
      <CartProvider>
        <Router>
          <RenderWithSidebar />
        </Router>
      </CartProvider>
    </AuthProvider>
  );
};

const RenderWithSidebar = () => {
  const location = useLocation();
  const noSidebarRoutes = ['/', '/login', '/register'];

  return (
    <div className="app">
      {!noSidebarRoutes.includes(location.pathname) && <Sidebar />}
      <div className="main-content">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/register" element={<Register />} />
          <Route path="/login" element={<Login />} />
          <Route path="/orders" element={<OrdersPage />} />
          <Route path="/books/:id" element={<BookDetail />} />
          <Route path="/books" element={<BookList />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/categories/fiction" element={<FictionPage />} />
          <Route path="/categories/action" element={<ActionPage />} />
          <Route path="/categories/romance" element={<RomancePage />} />
          <Route path="/categories/scifi" element={<SciFiPage />} />
          <Route path="/categories/mystery" element={<MysteryPage />} />
        </Routes>
      </div>
    </div>
  );
};

export default App;
