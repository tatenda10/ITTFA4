import React from 'react'

function MysteryPage() {
  return (
    <div>
      MysteryPage
    </div>
  )
}

export default MysteryPage
