import React from 'react'

function ActionPage() {
  return (
    <div>
      ActionPage
    </div>
  )
}

export default ActionPage
