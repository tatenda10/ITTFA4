import React from 'react'

function RomancePage() {
  return (
    <div>
      RomancePage
    </div>
  )
}

export default RomancePage
