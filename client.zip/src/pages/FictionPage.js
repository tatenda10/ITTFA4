import React from 'react'

function FictionPage() {
  return (
    <div>
      FictionPage
    </div>
  )
}

export default FictionPage
