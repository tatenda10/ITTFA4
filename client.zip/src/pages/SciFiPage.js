import React from 'react'

function SciFiPage() {
  return (
    <div>
      SciFiPage
    </div>
  )
}

export default SciFiPage
