import React, { useEffect, useState } from 'react';
import { fetchOrdersByUserId } from '../services/api';
import { useAuth } from '../context/AuthContext';

const OrdersPage = () => {
  const [orders, setOrders] = useState([]);
  const { user } = useAuth();

  useEffect(() => {
    if (user) {
      const getOrders = async () => {
        const ordersData = await fetchOrdersByUserId(user.id);
        setOrders(ordersData);
      };

      getOrders();
    }
  }, [user]);

  return (
    <div className="p-4">
      <h2 className="text-2xl font-bold mb-4">Orders</h2>
      {orders.length === 0 ? (
        <p>No orders found.</p>
      ) : (
        <ul>
          {orders.map((order) => (
            <li key={order.id} className="mb-6 p-4 border border-gray-300 rounded-lg">
              <h3 className="text-xl font-semibold mb-2">Order ID: {order.id}</h3>
              <p className="mb-2">Date: {new Date(order.createdAt).toLocaleDateString()}</p>
              <p className="mb-2">Total: {order.total}</p>
              <h4 className="text-lg font-semibold mb-2">Items:</h4>
              <ul className="list-disc list-inside">
                {order.items.map((item) => (
                  <li key={item.id} className="ml-4 mb-2">
                    {item.title} by {item.author} - {item.quantity} x ${item.price}
                  </li>
                ))}
              </ul>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default OrdersPage;
