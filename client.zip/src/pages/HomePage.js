import React from 'react';
import { useNavigate } from 'react-router-dom';
import backgroundImage from '../assets/background.jpg'; // Replace with the correct path

const HomePage = () => {
  const navigate = useNavigate();

  return (
    <div className="h-screen bg-cover bg-center flex justify-center items-center" style={{ backgroundImage: `url(${backgroundImage})` }}>
      <div className="text-center bg-white p-8 rounded-lg shadow-lg">
        <h1 className="text-4xl font-bold mb-4">Welcome to Katylgo Book Store</h1>
        <button onClick={() => navigate('/login')} className="bg-blue-500 text-white p-4 rounded">
          Get Started
        </button>
      </div>
    </div>
  );
};

export default HomePage;
